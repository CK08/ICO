clear all
clc

syms gn a11 b11
syms a

m=a11-gn*b11;

a=gn/m;

a2=simplify(a)